package com.example.demo.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Model.SensorData;
import com.example.demo.dao.SensorDataDAO;

@Service
public class SensorDataService {
	
	@Autowired
	SensorDataDAO dao;
	
	private List<String> fileLines;
	
	/*
	 * Use as stand alone progam to store CSV file into database
	 * */
	public void readCSVfile() throws IOException, InterruptedException {
		
		TimerTask timerTask = new MyTimerTask();
		Timer timer = new Timer(true);
		timer.scheduleAtFixedRate(timerTask, 0, 10*1000);
		
		System.out.println("TimerTask started");		 
		String fileLocation  = "D:\\MyWorkSpace\\New folder\\test_data\\test_data.csv";
		try(Stream<String> lines = Files.lines(Paths.get(fileLocation));){
			List<List<String>> values = lines.skip(1).map( x->Arrays.asList(x.split(","))).collect(Collectors.toList());
			for(List<String> value : values) {					
				fileLines = value;
				System.out.println("Data inserted.");
				
			}
		}	
				
	}

	
	


	public void formatDataToSave() {
		SensorData data = new SensorData();
		data.setStrDS(fileLines.get(0));
		data.setStrPV(fileLines.get(1));
		data.setStrQV(fileLines.get(2));
		data.setStrSV(fileLines.get(3));
		data.setStrTV(fileLines.get(4));
		data.setStrPOWER(fileLines.get(5));
		data.setStrVOLTAGE(fileLines.get(6));
		data.setStrFREQUENCY(fileLines.get(7))	;
		data.setStrTORQUE(fileLines.get(8));
		data.setStrTRIP_ALARM(fileLines.get(9));
		data.setLgTime(System.currentTimeMillis());
		dao.save(data);
		
	}
	
	
	
	
	/*
	 *Used to display the datas in the specifed time peried
	 *Param 
	 *1. Starttime - Starting time for search
	 *2. Interval - D- days/H-hours/M-Minite/S-seconds
	 
	 *
	 **/
	public List<SensorData> displaySensorData(Date StartTime,int interval, String period) {
		
		Calendar calendar = Calendar.getInstance();
		
		calendar.setTime(StartTime);
		Date startDate = calendar.getTime();
		switch(period) {
		
		case "D":
			calendar.add(Calendar.DATE, interval);
			break;
		case "H":
			calendar.add(Calendar.HOUR, interval);
			break;
		case "M":
			 calendar.add(Calendar.MINUTE, interval);
				break;
		case "S":
			calendar.add(Calendar.SECOND, interval);
			break;		
			
		}		
		Date endDate =  calendar.getTime();
		
		System.out.println(startDate.getTime() + "--" +endDate.getTime());
		
        return dao.findByLgTimeBetween(startDate.getTime(),endDate.getTime());
		
	}

}
