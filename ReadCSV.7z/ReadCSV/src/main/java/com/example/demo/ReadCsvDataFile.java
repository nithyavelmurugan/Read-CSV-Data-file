package com.example.demo;

import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;

import com.example.demo.service.SensorDataService;

public class ReadCsvDataFile {

	
	//Stand alone application to read csv file data. 
	public static void main(String args[]) throws InterruptedException {
		 ApplicationContext ctx = SpringApplication.run(ReadCsvApplication.class, args);

	      SensorDataService bean = ctx.getBean(SensorDataService.class);
	      try {
			bean.readCSVfile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
