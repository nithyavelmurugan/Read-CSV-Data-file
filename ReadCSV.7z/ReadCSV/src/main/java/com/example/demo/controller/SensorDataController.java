package com.example.demo.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.SensorData;
import com.example.demo.service.SensorDataService;

@RestController
public class SensorDataController {
	
	@Autowired
	SensorDataService service;
	
	@GetMapping("/")
	public String testAPI() {
		return "success";
	}
	

	
	//@RequestMapping(value = "displaySensor/{strDate}/{interval}/{period}", method = RequestMethod.GET)
	@RequestMapping(value="displaySensor/{strDate}/{interval}/{period}", method=RequestMethod.GET)
	//public ResponseEntity<List<SensorData>> displaySensor(@RequestParam("strDate") String strDate,@RequestParam("interval") String interval ,@RequestParam("period") String period) {
	public ResponseEntity<List<SensorData>> displaySensor(@PathVariable("strDate") String strDate,@PathVariable("interval") String interval ,@PathVariable("period") String period) {
		System.out.println("test");
		Date startDate;
		try {
			startDate = new SimpleDateFormat("ddMMyyyyHHmmss").parse(strDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block		@
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		List<SensorData> data = service.displaySensorData(startDate,  Integer.parseInt(interval), period);
		return new ResponseEntity<>(data,HttpStatus.OK);
	}
	

}
