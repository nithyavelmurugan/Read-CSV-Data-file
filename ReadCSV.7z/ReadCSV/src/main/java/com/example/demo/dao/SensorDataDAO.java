package com.example.demo.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.Model.SensorData;

@Repository
public interface SensorDataDAO extends MongoRepository<SensorData, String> {

	//This method is used to retrieve the dates between the start and end date. 
	List<SensorData> findByLgTimeBetween(Long startDate, Long endDate);
	
	
}
