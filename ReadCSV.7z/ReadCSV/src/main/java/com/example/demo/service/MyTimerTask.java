package com.example.demo.service;

import java.util.Date;
import java.util.TimerTask;

import org.springframework.beans.factory.annotation.Autowired;

public class MyTimerTask extends TimerTask {

	@Autowired
	SensorDataService ser;
	
	@Override
    public void run() {
        System.out.println("Timer task started at:"+new Date());
        completeTask();
        System.out.println("Timer task finished at:"+new Date());
    }
	
	private void completeTask() {
        try {
            //assuming it takes 20 secs to complete the task
        	ser.formatDataToSave();
            Thread.sleep(20000000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
