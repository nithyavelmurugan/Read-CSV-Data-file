package com.example.demo.Model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection= "dataFile")
public class SensorData{

	String strDS;
	String strPV;
	String strQV;
	String strSV;
	String strTV;
	String strPOWER;
	String strVOLTAGE;
	String strFREQUENCY;	
	String strTORQUE;
	String strTRIP_ALARM;
	long lgTime;
	
	public String getStrDS() {
		return strDS;
	}
	public void setStrDS(String strDS) {
		this.strDS = strDS;
	}
	public String getStrPV() {
		return strPV;
	}
	public void setStrPV(String strPV) {
		this.strPV = strPV;
	}
	public String getStrQV() {
		return strQV;
	}
	public void setStrQV(String strQV) {
		this.strQV = strQV;
	}
	public String getStrSV() {
		return strSV;
	}
	public void setStrSV(String strSV) {
		this.strSV = strSV;
	}
	public String getStrTV() {
		return strTV;
	}
	public void setStrTV(String strTV) {
		this.strTV = strTV;
	}
	public String getStrPOWER() {
		return strPOWER;
	}
	public void setStrPOWER(String strPOWER) {
		this.strPOWER = strPOWER;
	}
	public String getStrVOLTAGE() {
		return strVOLTAGE;
	}
	public void setStrVOLTAGE(String strVOLTAGE) {
		this.strVOLTAGE = strVOLTAGE;
	}
	public String getStrFREQUENCY() {
		return strFREQUENCY;
	}
	public void setStrFREQUENCY(String strFREQUENCY) {
		this.strFREQUENCY = strFREQUENCY;
	}
	public String getStrTORQUE() {
		return strTORQUE;
	}
	public void setStrTORQUE(String strTORQUE) {
		this.strTORQUE = strTORQUE;
	}
	public String getStrTRIP_ALARM() {
		return strTRIP_ALARM;
	}
	public void setStrTRIP_ALARM(String strTRIP_ALARM) {
		this.strTRIP_ALARM = strTRIP_ALARM;
	}
	public long getLgTime() {
		return lgTime;
	}
	public void setLgTime(long lgTime) {
		this.lgTime = lgTime;
	}
	
	
	
	
	
	

}
